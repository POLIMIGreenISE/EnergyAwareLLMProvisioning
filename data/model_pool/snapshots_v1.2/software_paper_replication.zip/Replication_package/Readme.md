# REPLICATION PACKAGE CONTENT
- data/: jupyter notebooks utilized to draw the plots
- - xlsx/: recorded data for A100 and RTX3070
- - A100-plots.ipynb: draw figures related to gpu A100
- - RTX3070-plots.ipynb: draw figures related to RTX3070
- - label_color_dict.json: colors for figure 3 to use a uniform colors with figure 2
- src/: scripts for running models, getting completions and recording energy
- - bug_fixing/inference.py: querying models for bug fixing task 
- - code_generation/inference.py: querying models for code generation task 
- - code_generation/inference_v2.py: same as inference.py including code for recording cpu energy
- - docstring_generation/inference.py: querying models for docstring generation task 
- - docstring_generation/docstring2code.py: script to get the codes based on generated docstrings
- - test_generation/inference.py: querying models for test generation task 
- - test_generation/report_coverage.ipynb: reporting coverage for generated test assertions
- - get_polished_code.ipynb: extracting the intended response from the raw answers
- - gpu_energy_recorder.py: recording the power consumption of the gpu
- - model_specification.ipynb: combining the recorded model's information
- - main_get_completion.py: loading the intended model and sen the query
- - warm_up.py: warming up the gpu before recording its power
- - model_info.py: recording models' information
- - idle_rapl: for measuring cpu idle power
- - cluster_models.txt: list of model's name employed in this study
- environment.yml: YAML file to create the conda environment
-  appendix.html: all the appendices of the paper

# SETUP
- Install [Ollama](https://ollama.com/download)

 
- - Download models listed in **cluster_models.txt** using the following command: [Ollama Documentation](https://github.com/ollama/ollama?tab=readme-ov-file#pull-a-model)
- - Ollama pull model_name
 
- Install [Conda](https://docs.conda.io/projects/conda/en/latest/user-guide/install/index.html#installing-conda)
- - Creating an environment from the provided **environment.yml** file [Conda Documentation](https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html#creating-an-environment-from-an-environment-yml-file)
- To record gpu's idle power run the following command in the terminal:
- - `timeout 340s nvidia-smi -lms=100 --query-gpu=power.draw --format=csv -f output.csv`
