import pynvml
import threading
import csv
class GPURecorder:
    def __init__(self, filename, measurement_interval):
        self.filename = filename
        self.measurement_interval = measurement_interval
        self.stop_event = threading.Event()
        self.records_list = [['power (W)', 'pState', 'gpu_utilization', 'memory_utilization']]
        pynvml.nvmlInit()
        self.gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        self.mW_to_W = 1000

    def get_gpu_power(self):
        if not self.stop_event.is_set():
            threading.Timer(self.measurement_interval, self.get_gpu_power).start()
            power_draw = pynvml.nvmlDeviceGetPowerUsage(self.gpu_handle) / self.mW_to_W
            pstat = pynvml.nvmlDeviceGetPowerState(self.gpu_handle)
            util = pynvml.nvmlDeviceGetUtilizationRates(self.gpu_handle)
            self.records_list.append([power_draw, pstat, util.gpu, util.memory])

    def start(self):
        self.get_gpu_power()

    def stop(self):
        self.stop_event.set()
        pynvml.nvmlShutdown()
        with open(self.filename, mode='a', newline='') as file:
            writer = csv.writer(file)
            for record in self.records_list:
                writer.writerow(record)