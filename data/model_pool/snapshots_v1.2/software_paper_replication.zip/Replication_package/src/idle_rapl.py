import pyRAPL
import time

pyRAPL.setup()

measure = pyRAPL.Measurement("cpu_idle_power")
idle_time = 3400 #sec
measure.begin()
time.sleep(idle_time)
measure.end()

idle_energy = measure.result.pkg
idle_duration = measure.result.duration
idle_power = float(idle_energy[0]) / idle_duration

print(f'idle energy: {float(idle_energy[0])}, idle duration: {idle_duration}')
print(f'idle power over {idle_time} seconds: {idle_power}')
