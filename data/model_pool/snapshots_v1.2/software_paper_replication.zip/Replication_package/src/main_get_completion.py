import ollama
import time

# Query the llm
def send_query(model_name, prompt, system_message, options):
    return ollama.generate(model=model_name, prompt=prompt, stream=False, options=options, system=system_message)

def unload_model(model_name):
    return ollama.generate(model=model_name, keep_alive=0)

def load_model(model_name):
    return ollama.generate(model=model_name, keep_alive=-1)

def get_completion(model_name, df, system_message, options):
    sum_output_tokens_num = 0
    sum_input_tokens_num = 0
    sum_prompt_eval_duration = 0
    sum_eval_duration = 0
    sum_total_duration = 0
    sum_tokens_per_sec = 0
    count = 0
    unfinished = 0
    output_response = []
    print(f'\nStarting {model_name}...\n')
    start_load_time = time.time()
    load_model(model_name)
    end_load_time = time.time()

    for row in df.itertuples(index=True, name='Problem'):
        # print(row.new_prompt)
        response = send_query(model_name, row.new_prompt, system_message, options)

        # print(response)
        if response["done"]:
            res_dictionary = {
                "task_id": row.task_id.replace("Python/", "HumanEval/"),
                "completion": response["response"],
                "prompt_eval_count": response["prompt_eval_count"],
                "prompt_eval_duration": response["prompt_eval_duration"],
                "eval_count": response["eval_count"],
                "eval_duration": response["eval_duration"],
                "total_duration": response["total_duration"],
                "token_per_second": response["eval_count"] / response["total_duration"] * 1e9
            }
            sum_input_tokens_num += response["prompt_eval_count"]
            sum_output_tokens_num += response["eval_count"]
            sum_prompt_eval_duration += response["prompt_eval_duration"]
            sum_eval_duration += response["eval_duration"]
            sum_total_duration += response["total_duration"]
            sum_tokens_per_sec += (response["eval_count"] / response["total_duration"] * 1e9)
            count += 1
        else:
            res_dictionary = {
                "task_id": row.task_id.replace("Python/", "HumanEval/"),
                "completion": "",
                "prompt_eval_count": 0,
                "prompt_eval_duration": 0,
                "eval_count": 0,
                "eval_duration": 0,
                "total_duration": 0,
                "token_per_second": 0
            }
            print(f'incomplete: {row.task_id}:\n{response}')
            unfinished += 1

        output_response.append(res_dictionary)

    end_time = time.time()
    unload_model(model_name)
    end_unload_time = time.time()
    model_log = {
        "done": count,
        "unfinished": unfinished,
        "total_input_tokens": sum_input_tokens_num,
        "total_output_tokens": sum_output_tokens_num,
        "prompt_eval_duration": sum_prompt_eval_duration,
        "eval_duration": sum_eval_duration,
        "total_duration": sum_total_duration,
        "tokens_per_sec": sum_tokens_per_sec,
        "total_elapsed_time": end_time - end_load_time,
        "model_load_time": end_load_time - start_load_time,
        "model_unload_time": end_unload_time - end_time
    }

    return output_response, model_log


