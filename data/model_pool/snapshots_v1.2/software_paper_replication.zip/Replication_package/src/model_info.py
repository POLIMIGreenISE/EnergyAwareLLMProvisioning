import ollama
import json

with open("cluster_models.txt", "r") as models_list:
    quantized_models = models_list.read()
models = quantized_models.split("\n")

model_info = []
for model in models:
    show_res = ollama.show(model)
    model_info.append({
        'name': model,
        'details': show_res['details'],
        'model_info': show_res['model_info']
    })

eval_filename = 'model_info.jsonl'
outfile = open(f'{eval_filename}', "ab")
for info in model_info:
    outfile.write((json.dumps(info) + "\n").encode('utf-8'))

outfile.close()