import pandas as pd
import json
import time
import os
import sys

parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(parent_dir)
import main_get_completion
import gpu_energy_recorder


with open("../cluster_models.txt", "r") as models_list:
    quantized_models = models_list.read()
models = quantized_models.split("\n")
print(models)

df = pd.read_json("../humanevalpack_extra_docstring_assertion_example.jsonl", lines=True)


system_message = 'You are an exceptionally intelligent AI assistant that consistently delivers accurate and reliable Python assertions for testing a function aiming to maximize branch coverage and statement coverage. without adding natural language explanations or importing unittest or making new classes.'
temperature = 0.1
top_p = 0.95
seed = 42
token_limit = 900
options = {
    "temperature": temperature,  # default:0.8
    "top_p": top_p,  # default:0.9
    "seed": seed,
    "num_predict": token_limit,
}

prompt_template = """
Generate a number of Assertions in Python for the following function:

### Instruction
{instruction}

### Assertions
{response}
"""

def set_prompt(row):
    prompt = prompt_template.format(
        instruction=f'{row.prompt}{row.canonical_solution}',
        response=f'{row.example_assert}'
    )
    return prompt

df['new_prompt'] = df.apply(set_prompt, axis=1)


models_log = {}
#Record the energy
measurement_interval = 0.1  # in seconds ( = 10 Hz)
energy_root = "energy"
# Write in a jsonl file to calculate pass@1
eval_root = "eval"
stat_root = "stat"

for i in range(3):
    print(f"round {i+1} ...")
    for model in models:
        model_name = model
        delimiter = model_name.find("_")
        energy_filename = f'{energy_root}/test_gen_{model_name[:delimiter]}'
        gpu_file_name = f'{energy_filename}_gpu.csv'
        gpu_recorder = gpu_energy_recorder.GPURecorder(gpu_file_name, measurement_interval)

        # start recording gpu energy now and every [measurement_interval] sec
        gpu_recorder.start()
        # inference on the whole data frame (all the 164 tasks)
        result, model_log = main_get_completion.get_completion(model_name, df, system_message, options)

        gpu_recorder.stop()

        models_log[f'{model_name}_r{i}'] = model_log

        stat_filename = f'{stat_root}/test_gen_{model_name[:delimiter]}.jsonl'
        outfile = open(f'{stat_filename}', "ab")
        for data in result:
            statistic_values = {key: data[key] for key in data if key not in ["completion"]}
            outfile.write((json.dumps(statistic_values) + "\n").encode('utf-8'))

        if i == 0:
            eval_filename = f'{eval_root}/test_gen_{model_name[:delimiter]}.jsonl'
            outfile = open(f'{eval_filename}', "ab")
            for data in result:
                completion_values = {key: data[key] for key in ["task_id", "completion"]}
                outfile.write((json.dumps(completion_values) + "\n").encode('utf-8'))

            outfile.close()

        time.sleep(30)

with open(f'{energy_root}/models_log_test_gen.jsonl', mode='a', newline='') as file:
    for key, value in models_log.items():
        json_line = json.dumps({key: value})
        file.write(json_line + '\n')

print("All done!")
