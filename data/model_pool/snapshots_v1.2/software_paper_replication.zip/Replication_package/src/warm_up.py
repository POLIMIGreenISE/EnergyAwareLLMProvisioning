import main_get_completion
import pandas as pd

with open("cluster_models.txt", "r") as models_list:
    quantized_models = models_list.read()
models = quantized_models.split("\n")

df = pd.read_json("humanevalpack_extra_docstring_assertion_example.jsonl", lines=True)


system_message = 'You are an exceptionally intelligent AI assistant that consistently delivers syntactically and semantically correct and reliable Python code. Without any explanations in natural language.'
temperature = 0.1
top_p = 0.95
seed = 42
token_limit = 336
options = {
    "temperature": temperature,  # default:0.8
    "top_p": top_p,  # default:0.9
    "seed": seed,
    "num_predict": token_limit,
}


prompt_template = """
Generate only the Python Code according to the Instruction:

### Instruction
{instruction}

### Python Code
{response}
"""


def set_prompt(row):
    prompt = prompt_template.format(
        instruction=row.prompt,
        response=row.declaration
    )
    return prompt

df['new_prompt'] = df.apply(set_prompt, axis=1)


# warming up
print("Warming up ...")
warm_up_model_name = models[0]
main_get_completion.get_completion(warm_up_model_name, df.head(10), system_message, options)
